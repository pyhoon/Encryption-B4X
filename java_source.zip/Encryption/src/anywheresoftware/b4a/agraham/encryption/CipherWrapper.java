package anywheresoftware.b4a.agraham.encryption;

import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import anywheresoftware.b4a.BA.Author;
import anywheresoftware.b4a.BA.ShortName;
import anywheresoftware.b4a.BA.Version;

/**
 *This object  provides the functionality of a secret (symmetric) key encryptor and
 *decryptor. The algorithms may commonly be one of the following, there are others not listed here.
 *
 *AES also known as Rijndael is a 128-bit block cipher supporting keys of 128, 192, and 256 bits.
 *DES The Digital Encryption Standard as described in FIPS PUB 46-3.
 *DESede Triple DES Encryption (also known as DES-EDE, 3DES, or Triple-DES).
 */
@ShortName("Cipher")
@Version(1.1f)
@Author("Andrew Graham")
public class CipherWrapper
{
	// 1.0 	initial release
	// 1.1	added KeyPairGenerator, Mac and Signature
	private static final double version = 1.1;
	
	/**
	 *This library implements various encryption and encoding methods
	 *
	 *The following objects are available:
	 *
	 *Base64: used to encode and decode data in Base64 representation.
	 *Cipher: used for encrypting/decrypting data.
	 *KeyGenerator: used to generate and mainpulate secret keys for symmetric ciphers.
	 *MAC: (Message Authentication Code) used generate secret key encrypted message digests.
	 *MessageDigest: used to calculate the message digest (hash) of specified data.
	 *SecureRandom: used to generate pseudo-random numbers.
	 *Signature: are used to sign data and verify digital signatures.
	 *
	 *More information is given on each object in its help comments.
	 *
	 *These comments are intended to document the facilities provided by this library.
	 *They are not intended in any way to cover their practical use. It is assumed that
	 *you know what you are doing when you use this library.
	 *
	 *Documentation on the Java Cryptography Architecture may be found in the <link>JCA document|http://download.oracle.com/javase/6/docs/technotes/guides/security/crypto/CryptoSpec.html</link>
	 *
	 *A list of standard names used in the Java Cryptography Architecture may be found in the <link>Java Standard Names document|http://download.oracle.com/javase/6/docs/technotes/guides/security/StandardNames.html</link>
	 *
	 *Any implementation does not neccessarily include the complete list. A list of included
	 *Service Providers may be obtained with the Cipher.GetServices method and they may be passed
	 *individually to Cipher.GetAlgorithms to get the list of supported algorithms for that provider.
	 */
	public void LIBRARY_DOC()
	{
	}

	Cipher cipher;
	byte[] iv;
	
	
	/**
	 * Initialises the Cipher object to perform the supplied transformation.
	 * 
	 *A transformation is a string that describes the operation (or set of operations) to be performed
	 *on the given input to produce some output. A transformation always includes the name of a
	 *cryptographic algorithm (e.g., DES), and may be followed by a mode and padding scheme.
	 *
	 *A transformation is of the form "algorithm/mode/padding" or "algorithm".
	 *For example, the following are valid transformations:
	 *"DES/CBC/PKCS5Padding"
	 *"DES" note that this is actually a synonym for "DES/ECB/PKCS5Padding".
	 *"DES/ECB/NoPadding" use this for simple single block encoding.
	 *
	 *Algorithm may commonly be one of the following, there are others not listed here.
	 *AES also known as Rijndael is a 128-bit block cipher supporting keys of 128, 192, and 256 bits.
	 *DES The Digital Encryption Standard as described in FIPS PUB 46-3.
	 *DESede Triple DES Encryption (also known as DES-EDE, 3DES, or Triple-DES).
	 *
	 *Mode may commonly be one of the following, there are others not listed here.
	 *NONE No mode.
	 *CBC Cipher Block Chaining Mode, as defined in FIPS PUB 81.
	 *CFB, CFBx Cipher Feedback Mode, as defined in FIPS PUB 81.
	 *ECB Electronic Codebook Mode, as defined in FIPS PUB 81. 
	 *OFB, OFBx Output Feedback Mode, as defined in FIPS PUB 81.
	 *Using modes such as CFB and OFB, block ciphers can encrypt data in units smaller than
	 * the cipher's actual block size. When requesting such a mode, you may optionally specify the
	 * number of bits to be processed at a time by appending this number to the mode name as shown
	 * in the "DES/CFB8/NoPadding" and "DES/OFB32/PKCS5Padding" transformations. If no such
	 * number is specified, a provider-specific default is used. Thus block ciphers can be turned into
	 * byte-oriented stream ciphers by using an 8 bit mode such as CFB8 or OFB8.
	 *  
	 *Padding may be one of
	 *NoPadding 
	 *ISO10126Padding
	 *PKCS1Padding The padding scheme described in PKCS1, used with the RSA algorithm.
	 *PKCS5Padding The padding scheme described in RSA Laboratories, "PKCS5: version 1.5, November 1993.
	 *SSL3Padding The padding scheme defined in the SSL Protocol Version 3.0, November 18, 1996,
	 * section 5.2.3.2 (CBC block cipher): 
	 */	
	public void Initialize(String transformation) throws Exception
	{
		cipher = Cipher.getInstance(transformation);
	}
	
	
	private byte[] doFinal(int mode, byte[] data, Key key, boolean useIV) throws Exception
	{
		if (useIV)
		{
        IvParameterSpec ips = new IvParameterSpec(iv);
        cipher.init(mode, key, ips);
		}
		else
	        cipher.init(mode, key);		
        return cipher.doFinal(data);
	}
	
	/**
	 *Encrypts the supplied data using the key provided. If an initialisation vector is
	 *to be used then useIV should be set True and the InitialisationVector property set
	 *to the required data.
	 */
	public byte[] Decrypt(byte[] data, Key key, boolean useIV) throws Exception
	{
        return doFinal(Cipher.DECRYPT_MODE, data,  key, useIV);
	}
	
	/**
	 *Decrypts the supplied data using the key provided. If an initialisation vector is
	 *to be used then useIV should be set True and the InitialisationVector property set
	 *to the required data.
	 */
	public byte[] Encrypt(byte[] data, Key key, boolean useIV) throws Exception
	{
	    return doFinal(Cipher.ENCRYPT_MODE, data,  key, useIV);
	}
	

	/**
	 *Returns an array of strings containing the algorithms that the specified security
	 *provider implements.
	 */
	public String[] GetAlgorithms(String servicename)
	{
		ArrayList<String> result = new ArrayList<String>();
		Object[] algos = Security.getAlgorithms(servicename).toArray();
		for (Object o : algos)
		{
			String svc = (String) o;
			result.add(svc);
		}
	    Collections.sort(result);
		return (String[]) result.toArray(new String[result.size()]);
	}


	/**
	 *Returns an array of strings containing the security providers present on the system.
	 */
	public String[] GetServices()
	{
		ArrayList<String> result = new ArrayList<String>();
		Provider[] providers = Security.getProviders();
		for (int i = 0; i < providers.length; i++)
		{
			Set<Provider.Service> svcs = providers[i].getServices();
			for (Object o : svcs)
			{
				Provider.Service svc = (Provider.Service) o;
				if (!result.contains(svc.getType()))
					result.add(svc.getType());
			}
		}
	    Collections.sort(result);
		return (String[]) result.toArray(new String[result.size()]);
	}

	/**
	 *Returns the version number of the library.
	 */
	public double getVersion()
	{
		return version;
	}
	
	/**
	 *Gets or sets the initialisation vector array. 
	 */
	public byte[] getInitialisationVector()
	{
		return iv;
	}
	public void setInitialisationVector(byte[] iv)
	{
		this.iv = iv;
	}
	

	/**
	 *Message digests are used to produce unique and reliable identifiers of data.
	 *They are sometimes called "checksums" or the "digital fingerprints" of the data.
	 *Changes to just one bit of the message should produce a different digest value.
	 *
	 *Algorithm can be "MD2", "MD5", "SHA-1", "SHA-256", "SHA-384" or "SHA-512".
	 */
	@ShortName("MessageDigest")
	public static class MessageDigestWrapper
	{
		
		/**
		 *Returns a byte array containing the message digest of the contents of the supplied
		 *array if bytes using the specified algorithm.
		 *Algorithm can be "MD5", "SHA-1", "SHA-224", "SHA-256", "SHA-384" or "SHA-512"
		 */
		public byte[] GetMessageDigest(byte[] data, String algorithm) throws Exception
		{
			MessageDigest md = MessageDigest.getInstance(algorithm);
			md.update(data);
			return md.digest();	
		}
		
		/**
		 *Returns the version number of the library.
		 */
		public double getVersion()

		{
			return version;
		}
	}
		
	/**
	 *A seed is an array of bytes used to bootstrap random number generation.
	 *To produce cryptographically secure random numbers, both the seed and the algorithm
	 *must be secure. By default, instances of this class will generate an initial seed
	 *using an internal entropy source. This seed is unpredictable and appropriate for secure use.
	 *You may alternatively specify the initial seed explicitly by calling setSeed(byte[]) before
	 *any random numbers have been generated. Specifying a fixed seed will cause the instance to
	 *return a predictable sequence of numbers. This may be useful for testing but it is not
	 *appropriate for secure use.
	 *
	 *Although it is common practice to seed Random with the current time, that is dangerous with
	 *SecureRandom since that value is predictable to an attacker and not appropriate for secure use.
	 */
	@ShortName("SecureRandom")
	public static class SecureRandomWrapper
	{
		SecureRandom srnd = new SecureRandom();
		
		/**
		 *Fills the provided array with cryptographically strong random numbers produced
		 *by the secure random number generator.
		 */
		public void GetRandomBytes(byte[] bytes)
		{
			srnd.nextBytes(bytes);
		}
		
		/**
		 *The random number generator seeds itself when created with a random seed. If it is
		 *required, say for testing purposes, to repeatedly reproduce the same sequence of
		 *random numbers then the generator may be seeded with a specific value before use. 
		 */
		public void SetRandomSeed(long seed)
		{
			srnd = new SecureRandom();		
			srnd.setSeed(seed);		
		}			
		
		/**
		 *Returns the version number of the library.
		 */
		public double getVersion()
		{
			return version;
		}
	}

	/**
	 *This object  provides the functionality of a secret (symmetric) key generator.
	 *KeyGenerator objects are reusable, i.e., after a key has been generated, the same
	 *KeyGenerator object can be re-used to generate further keys. 
	 *
	 *Algorithm may commonly be one of the following, there are others not listed here.
	 *AES also known as Rijndael is a 128-bit block cipher supporting keys of 128, 192, and 256 bits.
	 *DES The Digital Encryption Standard as described in FIPS PUB 46-3.
	 *DESede Triple DES Encryption (also known as DES-EDE, 3DES, or Triple-DES).
	 */
	@ShortName("KeyGenerator")
	public static class KeyGeneratorWrapper
	{
		private KeyGenerator kgen;
		private SecretKey key;
		
		/**
		 *Initialise this KeyGenerator to work with the specified algorithm.
		 */
		public void Initialize(String algorithm) throws Exception
		{
			kgen = KeyGenerator.getInstance(algorithm);			
		}		
		
		/**
		 *Creates and saves internally a SecretKey object appropriate for use with the specified
		 *algorithm using internally provided random data . 
		 */
		public SecretKey GenerateKey()
		{
			key = kgen.generateKey();
			return key;
		}
		
		/**
		 *Returns a byte array representing the SecretKey. 
		 */
		public byte[] KeyToBytes()
		{
			return key.getEncoded();
		}
		
		/**
		 *Creates and saves internally a SecretKey object appropriate for use with the specified
		 *algorithm using the data in the byte array provided. 
		 */
		public void KeyFromBytes(byte[] keydata)
		{
			key  = new SecretKeySpec(keydata, kgen.getAlgorithm());
		}
		
		/**
		 *Returns the format of the key data obtained by KeyToBytes. This will almost certainly be "RAW".
		 */
		public String getFormat()
		{
			return key.getFormat();
		}
		
		/**
		 *Gets or sets the SecretKey object. 
		 */
		public SecretKey getKey()
		{
			return key;
		}
		public void setKey(SecretKey key)
		{
			this.key = key;
		}		
		
		/**
		 *Returns the version number of the library.
		 */
		public double getVersion()
		{
			return version;
		}
	}

	/**
	 *The KeyPairGenerator is used to generate pairs of public and private keys.
	 *A key pair generator for a particular algorithm creates a public/private key pair
	 *that can be used with this algorithm. 
	 *
	 *Algorithm is commonly be the following, there may be others not listed here.
	 *RSA The RSA encryption algorithm as defined in PRSA Public-Key Cryptography Standards .
	 */
	@ShortName("KeyPairGenerator")
	public static class KeyPairGeneratorWrapper
	{
		KeyPairGenerator kpgen;
		KeyPair keypair;
		PublicKey publickey;
		PrivateKey privatekey;
		
		/**
		 *Initialises the KeyPairGenerator with the specified algorithm and keysize.
		 */
		public void Initialize(String algorithm, int keysize) throws Exception
		{
			kpgen = KeyPairGenerator.getInstance(algorithm);
			kpgen.initialize(keysize);
		}		
		
		/**
		 *Generates a key pair appropriate for use with the specified algorithm.
		 *This is a simple holder for a key pair (a public key and a private key).
		 *It does not enforce any security, and, when initialized, should be treated like
		 *a private key.
		 */
		public void GenerateKey()
		{
			keypair = kpgen.generateKeyPair();
			publickey = keypair.getPublic();
			privatekey =  keypair.getPrivate();
		}
		
		/**
		 *Returns a byte array in the X.509 format representing the PublicKey. 
		 */
		public byte[] PublicKeyToBytes()
		{
			return publickey.getEncoded();
		}
		
		/**
		 *Returns a byte array in the PKC#8 format representing the PrivateKey. 
		 */
		public byte[] PrivateKeyToBytes()
		{
			return privatekey.getEncoded();
		}
		
		/**
		 *Creates and saves internally a public key appropriate for use with the specified
		 *algorithm using the data in X.509 format from the byte array provided. 
		 */
		public void PublicKeyFromBytes(byte[] keydata) throws Exception
		{
			 X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(keydata);
	         KeyFactory keyFactory = KeyFactory.getInstance(kpgen.getAlgorithm());
	         publickey = keyFactory.generatePublic(pubKeySpec);
		}
		
		/**
		 *Creates and saves internally a private key appropriate for use with the specified
		 *algorithm using the data in the PKCS#8 format from the byte array provided. 
		 */
		public void PrivateKeyFromBytes(byte[] keydata) throws Exception
		{
			PKCS8EncodedKeySpec prvKeySpec = new PKCS8EncodedKeySpec(keydata);
			KeyFactory keyFactory = KeyFactory.getInstance(kpgen.getAlgorithm());
			privatekey = keyFactory.generatePrivate(prvKeySpec);
		}
		
		/**
		 *Gets the public key of the KeyPairGenerator object. 
		 */
		public PublicKey getPublicKey()
		{
			return publickey;
		}
		
		/**
		 *Gets the private key of the KeyPairGenerator object. 
		 */
		public PrivateKey getPrivateKey()
		{
			return privatekey;
		}		
		
		/**
		 *Returns the formats of the key data obtained by xxxKeyToBytes in a String array.
		 *The public key format is at index 0 and will almost certainly be "X.509".
		 *The private key format is at index 1 and will almost certainly be "PKCS#8".
		 */
		public String[] getFormats()
		{
			return new String[] { publickey.getFormat(), privatekey.getFormat()};
		}
		
		/**
		 *Returns the version number of the library.
		 */
		public double getVersion()
		{
			return version;
		}
	}
	
	/**
	 *Similar to a MessageDigest, a Signature provides a way to check the integrity of information
	 *transmitted over or stored in an unreliable medium and also ensures that it can be verified
	 *that it originated from the person it purports to originate from. It accomplishes this by using
	 *a private key to encode a hash of the original data and the corresponding public key of the key
	 *pair to decode and check that hash value.
	 *
	 *A Signature object is initialized for signing with a private key and is given the data
	 *to be signed. The resulting signature bytes are typically kept with the signed data.
	 *When verification is needed, another Signature object is created and initialized for 
	 *verification and given the corresponding public key. The data and the signature bytes
	 *are fed to the signature object, and if the data and signature match, the Signature
	 *object reports success.
	 *
	 */
	@ShortName("Signature")
	public static class SignaturerWrapper
	{
		Signature sig;
		
		public static final int SIGNATURE_VERIFY = 0;
		public static final int SIGNATURE_SIGN = 1;
		
		/**
		 *Initialises a Signature object that uses the specified algorithm for the specified mode.
		 *Mode must be either SIGNATURE_VERIFY or SIGNATURE_SIGN. Once the object is Initialised
		 *the data to be signed or verified is provided by one or more successive calls to Update.
		 *When the entire data to be signed or verified has been loaded Sign or Verify is called.
		 */
		public void Initialise(String algorithm, int mode, Key key) throws Exception
		{
			sig = Signature.getInstance(algorithm);
			if (mode == SIGNATURE_SIGN)
				sig.initSign((PrivateKey) key);
			else if(mode == SIGNATURE_VERIFY)
				sig.initVerify((PublicKey) key);
			else
				throw new RuntimeException("Signature - Invalid signature mode specified");
		}
		
		/**
		 *Sign the uploaded data using the private key provided on initialisation.
		 *Return the calculated signature data.
		 */
		public byte[] Sign() throws Exception
		{
			return sig.sign();
		}
		
		/**
		 *One or more calls to this method are required after initialisation to load the data to be
		 *signed or verified.
		 */
		public void Update(byte[] data) throws Exception
		{
			sig.update(data);			
		}
		
		/**
		 *Verify the uploaded data using the public key provided on initialisation and the signature
		 *provided. Return true if the verification is successful.
		 */
		public boolean Verify(byte[] signature) throws Exception
		{
			return sig.verify(signature);
		}
		
		/**
		 *Returns the version number of the library.
		 */
		public double getVersion()
		{
			return version;
		}
	}

	/**
	 *Similar to a MessageDigest, a Message Authentication Code (MAC) provides a way to check
	 *the integrity of information transmitted over or stored in an unreliable medium, but includes
	 *a secret key in the calculation. Only someone with the proper key will be able to verify the
	 *received message. Typically, message authentication codes are used between two parties that
	 *share a secret key in order to validate information transmitted between these parties.
	 *
	 *A MAC object is initialized for signing with a secret key and is given the data to be signed.
	 *The resulting signature bytes are typically kept with the signed data. When verification is needed,
	 *another MAC object is created and initialized with the same secret key.The data is uploaded and the
	 *signature obtained is compared with the signature provided with the message. The comparison may
	 *be made externally by comparing the signature provided with the data to that returned by Sign or
	 *the MAC object can do the comparison itself by using the Verify method with the provided signature.
	 */
	@ShortName("Mac")
	public static class MacWrapper
	{
		Mac mac;
		
		/**
		 *Initialises a Mac object that uses the specified algorithm and the specified secret key.
		 *Once the object is Initialised the data to be signed or verified is provided by one or more
		 *successive calls to Update. When the entire data to be signed or verified has been loaded
		 * Sign or Verify is called.
		 */
		public void Initialise(String algorithm, Key key) throws Exception
		{
			mac = Mac.getInstance(algorithm);
			mac.init(key);
		}
		
		/**
		 *Sign the uploaded data using the secret key provided on initialisation.
		 *Return the calculated signature data.
		 */
		public byte[] Sign() throws Exception
		{
			return mac.doFinal(null);
		}
		
		/**
		 *One or more calls to this method are required after initialisation to load the data to be
		 *signed or verified.
		 */
		public void Update(byte[] data) throws Exception
		{
			mac.update(data);			
		}
		
		/**
		 *Verify the uploaded data using the public key provided on initialisation and the signature
		 *provided. Return true if the verification is successful.
		 */
		public boolean Verify(byte[] signature) throws Exception
		{
			byte[]sig =  mac.doFinal(null);
			return Arrays.equals(sig, signature) ;
		}
		
		
		/**
		 *Returns the version number of the library.
		 */
		public double getVersion()
		{
			return version;
		}
	}


}
